function n=sample_norm(sigma)
n=sigma/6*sum(rand(12,1)*2-1);
end